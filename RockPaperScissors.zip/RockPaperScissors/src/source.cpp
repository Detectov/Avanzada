#include "game.h"

int main(){
    RPS game;
    game.play();
    return 0;
}